#include"stdio.h"
#include"string.h"

int copier(char *str){
	char buf[256];
	strcpy(buf,str);
} 

int main(int argc, char *argv[]){
	copier(argv[1]);
	printf("Done\n");

}











